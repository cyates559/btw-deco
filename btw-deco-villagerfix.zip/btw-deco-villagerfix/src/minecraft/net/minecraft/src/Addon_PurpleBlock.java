package net.minecraft.src;
public class Addon_PurpleBlock
{
	public Addon_PurpleBlock()
	{
	}
}
